
## DataFrames Excercise 1
# Write an expression to find the Per Capita GDP of Serbia in 2007.

## DataFrames Excercise 2: DataFrame slicing
1. Do the two statements below produce the same output?
1. Based on this, what rule governs what is included (or not) in numerical slices and named slices in Pandas?

print(data.iloc[0:2, 0:2])
print(data.loc['Albania':'Belgium', 'gdpPercap_1952':'gdpPercap_1962'])


## DataFrames Excercise 3
# Improve the following code with comments and better variable names

first = pandas.read_csv('data/gapminder_all.csv', index_col='country')
second = first[first['continent'] == 'Americas']
third = second.drop('Puerto Rico')
fourth = third.drop('continent', axis = 1)
fourth.to_csv('result.csv')

# bonus: is your current working directory the best place to save processed data?


## DataFrames Excercise 4
# Add documentation to the following excerpt and make yourself some notes about
# what `idxmin` and `idxmax` and where you would use them
data = pandas.read_csv('data/gapminder_gdp_europe.csv', index_col='country')
print(data.idxmin())
print(data.idxmax())

## DataFrames Excercise 5

# Using your gff file from the last lesson, can you subset the annotations to only those where the length of annotation is greater than 10000.  Below is some code to get you started fill in the "_____" sections

gff = pd.read_table('data/YpestisCO92.gff', skiprows=7, header = None, names = ['seqname','source','features','start','end','score','strand','frame','attribute'])
gff[gff[____]-gff[____] > ____]

# Bonus: How can you print the number of annotations which are in that subset?

# Bonus: What if we only want to count the coding sequences?  Hint: You should save the subset to a variable before trying to subset a second time.
