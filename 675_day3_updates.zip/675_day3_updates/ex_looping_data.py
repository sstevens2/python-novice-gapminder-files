## Data Looping Excercise 1
# Modify this program so that it prints the number of records in the file that has the fewest records.

import pandas
fewest = ____
for filename in glob.glob('data/*.csv'):
    dataframe = pandas.____(filename)
    fewest = min(____, dataframe.shape[0])
print('smallest file has', fewest, 'records')
